﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmEx3 : Form
    {
        public frmEx3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string texto = textBox1.Text;

            if (texto.Length > 50)
            {
                MessageBox.Show("O texto deve ter no máximo 50 caracteres.");
                return;
            }

            if (texto.Length < 1)
            {
                MessageBox.Show("Digite uma frase.");
                return;
            }

            // Remove espaços e deixa minúsculo
            texto = texto.Replace(" ", "").ToLower();

            // Inverte a string
            char[] vetor = texto.ToCharArray();
            Array.Reverse(vetor);

            string invertido = new string(vetor);

            // Verifica
            if (texto == invertido)
            {
                label1.Text = "É um palíndromo.";
            }
            else
            {
                label1.Text = "Não é um palíndromo.";
            }
        }
    }
}
