﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void AbrirForm(Form form)
        {
            panel1.Controls.Clear();

            form.TopLevel = false;

            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;

            panel1.Controls.Add(form);
            form.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AbrirForm(new frmEx1());

        }
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            AbrirForm(new frmEx2());

        }
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            AbrirForm(new frmEx3());

        }
        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            AbrirForm(new frmEx4());

        }
        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            AbrirForm(new frmPrincipal());

        }
    }
}
