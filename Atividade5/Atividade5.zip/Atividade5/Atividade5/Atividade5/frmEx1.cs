﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
            int count = 0;
            if (texto.Length > 100)
            {
                MessageBox.Show("Erro palavra muito grande");
                return;
            }
            else if (texto.Length < 1)
            {
                MessageBox.Show("Erro palavra muito pequena");
                return;
            }
            foreach (var item in texto)
            {
                if (item == ' ')
                    count++;
            }
            MessageBox.Show("Existem " + count + " Espaços");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
            int count = 0;
            if (texto.Length > 100)
            {
                MessageBox.Show("Erro palavra muito grande");
                return;
            }
            else if (texto.Length < 1)
            {
                MessageBox.Show("Erro palavra muito pequena");
                return;
            }
            for (int i = 0; i < texto.Length; i++)
            {
                string r = texto.Substring(i, i + 1).ToLower();
                if (r == "r")
                    count++;
            }
            MessageBox.Show("Existem " + count + " letras R");
        }
    }
}
