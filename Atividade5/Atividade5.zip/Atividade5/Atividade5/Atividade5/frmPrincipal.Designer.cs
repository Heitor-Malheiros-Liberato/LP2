﻿namespace Atividade5
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemSair = new System.Windows.Forms.ToolStripMenuItem();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.tsmItem2,
            this.tsmItem3,
            this.tsmItem4,
            this.tsmItemSair});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(105, 29);
            this.toolStripMenuItem1.Text = "Exercicio1";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // tsmItem2
            // 
            this.tsmItem2.Name = "tsmItem2";
            this.tsmItem2.Size = new System.Drawing.Size(105, 29);
            this.tsmItem2.Text = "Exercicio2";
            this.tsmItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // tsmItem3
            // 
            this.tsmItem3.Name = "tsmItem3";
            this.tsmItem3.Size = new System.Drawing.Size(105, 29);
            this.tsmItem3.Text = "Exercicio3";
            this.tsmItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // tsmItem4
            // 
            this.tsmItem4.Name = "tsmItem4";
            this.tsmItem4.Size = new System.Drawing.Size(105, 29);
            this.tsmItem4.Text = "Exercicio4";
            this.tsmItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // tsmItemSair
            // 
            this.tsmItemSair.Name = "tsmItemSair";
            this.tsmItemSair.Size = new System.Drawing.Size(57, 29);
            this.tsmItemSair.Text = "Sair";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(12, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 402);
            this.panel1.TabIndex = 1;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmPrincipal";
            this.Text = "Form Principal";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsmItem3;
        private System.Windows.Forms.ToolStripMenuItem tsmItem4;
        private System.Windows.Forms.ToolStripMenuItem tsmItemSair;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Panel panel1;
    }
}

