﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmEx2 : Form
    {
        public frmEx2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n;
            double h = 0;

            if (!int.TryParse(textBox1.Text, out n))
            {
                MessageBox.Show("Digite um número inteiro válido.");
                return;
            }

            if (n <= 0)
            {
                MessageBox.Show("O número N deve ser maior que 0.");
                return;
            }
            label1.Text = "";
            for (int i = 1; i <= n; i++)
            {
                h += 1.0 / i;
            }

            label1.Text = "H = " + h.ToString("F6");
        }
    }
}
