﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmEx4 : Form
    {
        public frmEx4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome = textBox1.Text;
            string matricula = textBox5.Text;

            int producao;
            double salario;
            double gratificacao;

            if (!int.TryParse(textBox4.Text, out producao))
            {
                MessageBox.Show("Produção inválida.");
                return;
            }

            if (!double.TryParse(textBox3.Text, out salario))
            {
                MessageBox.Show("Salário inválido.");
                return;
            }

            if (!double.TryParse(textBox2.Text, out gratificacao))
            {
                MessageBox.Show("Gratificação inválida.");
                return;
            }

            int B = 0;
            int C = 0;
            int D = 0;

            if (producao >= 100)
                B = 1;

            if (producao >= 120)
                C = 1;

            if (producao >= 150)
                D = 1;

            double percentual =
                (0.05 * B) +
                (0.10 * C) +
                (0.10 * D);

            double salarioBruto =
                salario +
                (salario * percentual) +
                gratificacao;

            // Restrição do exercício
            if (salarioBruto > 7000)
            {
                if (!(producao >= 150 && gratificacao > 0))
                {
                    MessageBox.Show(
                        "Salário bruto acima de 7000 só é permitido para produção >=150 com gratificação."
                    );
                    return;
                }
            }

            label1.Text =
                "Funcionário: " + nome +
                "\nMatrícula: " + matricula +
                "\nSalário Bruto: R$ " +
                salarioBruto.ToString("F2");
        }
    }
}
