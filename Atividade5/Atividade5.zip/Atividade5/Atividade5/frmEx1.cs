﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
            int count = 0;
            if (texto.Length > 100)
            {
                MessageBox.Show("Erro palavra muito grande");
                return;
            }
            else if (texto.Length < 1)
            {
                MessageBox.Show("Erro palavra muito pequena");
                return;
            }
            foreach (var item in texto)
            {
                if (item == ' ')
                    count++;
            }
            MessageBox.Show("Existem " + count + " Espaços");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
            int count = 0;
            if (texto.Length > 100)
            {
                MessageBox.Show("Erro palavra muito grande");
                return;
            }
            else if (texto.Length < 1)
            {
                MessageBox.Show("Erro palavra muito pequena");
                return;
            }
            for (int i = 0; i < texto.Length; i++)
            {
                char letra = char.ToLower(texto[i]);
                if (letra == 'r')
                    count++;
            }
            MessageBox.Show("Existem " + count + " letras R");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text.ToLower();
            int count = 0;
            int i = 0;

            if (texto.Length > 100)
            {
                MessageBox.Show("Erro: frase muito grande");
                return;
            }
            else if (texto.Length < 1)
            {
                MessageBox.Show("Erro: frase vazia");
                return;
            }

            while (i < texto.Length - 1)
            {
                if (texto[i] == texto[i + 1] && texto[i] != ' ')
                {
                    count++;
                    i += 2;
                }
                else
                {
                    i++;
                }
            }

            MessageBox.Show("Existem " + count + " pares de letras iguais.");
        }

        private void val_size(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
            if (texto.Length > 100)
            {
                MessageBox.Show("A frase deve ter no máximo 100 caracteres.");
                return;
            }
        }
    }
}
