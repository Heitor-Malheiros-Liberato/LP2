﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] num = new int[20];
            string mun = "";
            for (int i = 0; i < 20; i++)
            {
                num[i] = int.Parse(Interaction.InputBox("Coloque um numero", (i+1)+"numero"));
            }

            if (num.Length < 20)
            {
                MessageBox.Show("Erro numeros insuficientes");
                return;
            }
            for (int i = 19; i > -1; i--)
            {
                mun += num[i] + " ";
            }
            MessageBox.Show(mun);



        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            string lista = "";
            nomes.AddRange(new string[] { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" });
            nomes.Remove("Otávio");
            foreach (string nome in nomes)
            {
                lista += nome + "\n";
            }
            MessageBox.Show(lista);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[,] nTurma = new double[3, 20];
            string mediaG = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    int nota;
                    if (int.TryParse(Interaction.InputBox("Nota" + (j + 1), "Aluno" + (i + 1)), nota))
                    {
                        if (nota < 0 || nota > 10)
                        {
                            MessageBox.Show("Valor da nota Invalido");
                            j--;
                            continue;
                        }
                        nTurma[j, i] = nota;
                    }
                    else
                    {
                        j--;
                    }

                }
                mediaG += "Aluno " + (i+1) + ": Média " + Math.Round((nTurma[0, i] + nTurma[1, i] + nTurma[2, i])/3, 2) + "\n";
            }
            MessageBox.Show(mediaG);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 tela = new Form2();

            tela.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form3 tela = new Form3();

            tela.Show();
        }
    }
}
