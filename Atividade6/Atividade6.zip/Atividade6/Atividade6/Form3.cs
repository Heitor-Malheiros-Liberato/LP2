﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char[,] resp = new char[8,10];
            char[] gab = { 'E', 'B', 'A', 'C', 'D', 'B', 'A', 'C', 'E', 'A' }, alts = { 'A', 'B', 'C', 'D', 'E' };
            for (int j = 0; j < 8; j++)
            {
                for (int i = 0; i < 10; i++)
                {
                    string alt = Interaction.InputBox($"{i + 1}º Nota: ", $"{j + 1}º Aluno");
                    if (char.TryParse(alt.ToUpper(), out resp[j, i]))
                    {
                        if (!alts.Contains(resp[j, i]))
                        {
                            MessageBox.Show("Porfavor selecione uma alternativa valida.");
                            i--;
                            continue;
                        }
                    }
                    else
                    {
                        i--;
                        continue;
                    }
                }
            }
            for (int j = 0; j < 8; j++)
            {
                for(int i = 0;i < 10; i++)
                {
                    string text = $"O aluno {j + 1}";
                    if (resp[j,i] == gab[i])
                    {
                        text += " Acertou ";
                    }
                    else
                    {
                        text += " Errou ";
                    }
                    text += $"questão: {i + 1} era {gab[i]} escolheu {resp[j, i]}";
                    this.listBox1.Items.Add(text);
                }
            }
        }
    }
}
