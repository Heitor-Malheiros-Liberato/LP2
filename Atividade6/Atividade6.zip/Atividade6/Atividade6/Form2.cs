﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.listBox1.Items.Clear();
            string[] nomes = new string[10];
            int[] chara = new int[10];
            for (int i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox("Lista de Nomes", $"{i+1}º Nome: ");
                chara[i] = nomes[i].Length - nomes[i].Count(c => c == ' ');
            }
            for (int i = 0;i < nomes.Length;i++)
            {
                string texto = $"nome: {nomes[i]} tem {chara[i]} characteres";
                this.listBox1.Items.Add(texto);
            }
        }
    }
}
