﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PNotebook01
{
    public partial class Frm1 : Form
    {
        public Frm1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            double[,] metricas = new double[3,3];
            double[] mediaN = { 0, 0, 0 };
            double mediaT = 0;
            for (int note = 0; note < 3; note++)
            {
                for (int loja = 0; loja < 3; loja++)
                {
                    string aux = Interaction.InputBox($"Valor do {note + 1}º Notebook: ", $"{loja + 1}ª Loja");
                    if (aux == "")
                    {
                        return;
                    }
                    if (double.TryParse(aux, out double temp))
                    {
                        metricas[note, loja] = temp;
                        mediaN[note] += temp;
                    }
                    else
                    {
                        MessageBox.Show("Error: Valor invalido tente novamente!");
                        loja--;
                        continue;
                    }
                    if (metricas[note, loja] < 0)
                    {
                        MessageBox.Show("Error: Valor invalido tente novamente!");
                        loja--;
                        continue;
                    }
                }
                mediaN[note] = mediaN[note] / 3;
                mediaT += mediaN[note];
            }
            mediaT = mediaT/3;
            for (int note = 0; note < 3; note++)
            {
                lBox1.Items.Add($"Notebook :{note + 1} Loja 1:R${metricas[note, 0].ToString("n2")} Loja 2:R${metricas[note, 1].ToString("n2")} Loja 3:R${metricas[note, 2].ToString("n2")} Média:R${mediaN[note].ToString("n2")}");
            }
            lBox1.Items.Add("-----------------------------------------------------------");
            lBox1.Items.Add($"Média Geral Computadores: R${mediaT.ToString("n2")}\n");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            lBox1.Items.Clear();
        }
    }
}
