﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace AtividadeExtra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string[] diaSemana = { "Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sabado" };
            double[] totalPorDia = { 0, 0, 0, 0, 0, 0, 0 };
            double totalGeral = 0;
            double[,] dados = new double[7,5];
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    string text = Interaction.InputBox($"Produto {j + 1}:", diaSemana[i]);
                    if (text == "")
                        return;
                    if (double.TryParse(text, out double temp))
                    {
                        dados[i,j] = temp;
                        totalPorDia[i] += temp;
                    }
                    else
                    {
                        MessageBox.Show("Valor invalido tente novamente!");
                        j--;
                    }
                }
                totalGeral += totalPorDia[i];
                listBox1.Items.Add($"{diaSemana[i]}: {totalPorDia[i].ToString("n2")}");
            }
            listBox1.Items.Add("--------------------");
            listBox1.Items.Add($"Total Geral: {totalGeral.ToString("n2")}");

        }
    }
}
